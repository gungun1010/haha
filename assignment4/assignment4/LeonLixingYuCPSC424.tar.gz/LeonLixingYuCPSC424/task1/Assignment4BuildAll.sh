#!/bin/bash
module load Langs/Intel/14
make clean
make
