#!/bin/bash
module load GPU/Cuda/6.0
make
